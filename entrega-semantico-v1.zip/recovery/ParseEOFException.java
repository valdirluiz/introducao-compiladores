package recovery;

public class ParseEOFException extends Exception {
    public ParseEOFException(String x) {
        super(x);
    }
}
