package syntacticTree;

import parser.*;

public class CharConstNode extends ExpreNode {
    public CharConstNode(Token t) {
        super(t);
    }
}
