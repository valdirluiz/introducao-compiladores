package syntacticTree;

import parser.*;


abstract public class ExpreNode extends GeneralNode {
    public ExpreNode(Token t) {
        super(t);
    }
}
