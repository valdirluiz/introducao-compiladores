package syntacticTree;

import parser.*;

public class FloatConstNode extends ExpreNode {
    public FloatConstNode(Token t) {
        super(t);
    }
}
