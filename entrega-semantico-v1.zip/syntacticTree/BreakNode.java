package syntacticTree;

import parser.*;


public class BreakNode extends StatementNode {
    public BreakNode(Token t) {
        super(t);
    }
}
