package syntacticTree;

import parser.*;

public class AndNode  extends ExpreNode {
    public AndNode(Token t) {
        super(t);
    }
}
