package syntacticTree;

import parser.*;


public class StringConstNode extends ExpreNode {
    public StringConstNode(Token t) {
        super(t);
    }
}
