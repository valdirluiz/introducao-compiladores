package syntacticTree;

import parser.*;

public class BooleanConstNode extends ExpreNode{

  public BooleanConstNode(Token t) {
      super(t);
  }

}
