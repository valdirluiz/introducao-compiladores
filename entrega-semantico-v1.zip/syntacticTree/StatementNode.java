package syntacticTree;

import parser.*;


abstract public class StatementNode extends GeneralNode {
    public StatementNode(Token t) {
        super(t);
    }
}
