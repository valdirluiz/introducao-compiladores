package syntacticTree;

import parser.*;

public class OrNode  extends ExpreNode {
    public OrNode(Token t) {
        super(t);
    }
}
